package com.example.ozonshiftcatcher

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Local, user-maintained hierarchy. It is not loaded from an Ozon account. */
data class LocalWarehouseEntry(
    val name: String,
    val operations: List<String>
)

data class LocalRegionEntry(
    val name: String,
    val warehouses: List<LocalWarehouseEntry>
)

class LocalCatalogStore(context: Context) {
    // Keep the v1 preference bucket so existing v0.4.0 catalog entries can be migrated.
    private val preferences = context.getSharedPreferences("local_worker_catalog_v1", Context.MODE_PRIVATE)

    @Synchronized
    fun regions(): List<LocalRegionEntry> {
        val root = readRoot()
        val regionArray = root.optJSONArray("regions")
        if (regionArray != null) return parseRegions(regionArray)

        // Backward compatibility with v0.4.0: { "warehouses": [...] }.
        val legacyWarehouses = parseWarehouses(root.optJSONArray("warehouses") ?: JSONArray())
        if (legacyWarehouses.isEmpty()) return emptyList()
        val migrated = listOf(LocalRegionEntry(UNSPECIFIED_REGION, legacyWarehouses))
        saveRegions(migrated)
        return migrated
    }

    fun warehouses(regionName: String): List<LocalWarehouseEntry> =
        regions().firstOrNull { it.name.equals(regionName, ignoreCase = true) }?.warehouses.orEmpty()

    fun operations(regionName: String, warehouseName: String): List<String> =
        warehouses(regionName).firstOrNull { it.name.equals(warehouseName, ignoreCase = true) }
            ?.operations.orEmpty()

    @Synchronized
    fun addRegion(name: String): Boolean {
        val cleanName = normalize(name)
        if (cleanName.isBlank()) return false
        val entries = regions().toMutableList()
        if (entries.any { it.name.equals(cleanName, ignoreCase = true) }) return false
        entries.add(LocalRegionEntry(cleanName, emptyList()))
        saveRegions(entries)
        return true
    }

    @Synchronized
    fun addWarehouse(regionName: String, name: String): Boolean {
        val region = normalize(regionName)
        val cleanName = normalize(name)
        if (region.isBlank() || cleanName.isBlank()) return false
        val entries = regions().toMutableList()
        val index = entries.indexOfFirst { it.name.equals(region, ignoreCase = true) }
        if (index < 0) return false
        val oldRegion = entries[index]
        if (oldRegion.warehouses.any { it.name.equals(cleanName, ignoreCase = true) }) return false
        entries[index] = oldRegion.copy(
            warehouses = oldRegion.warehouses + LocalWarehouseEntry(cleanName, emptyList())
        )
        saveRegions(entries)
        return true
    }

    @Synchronized
    fun addOperation(regionName: String, warehouseName: String, operationName: String): Boolean {
        val region = normalize(regionName)
        val warehouse = normalize(warehouseName)
        val operation = normalize(operationName)
        if (region.isBlank() || warehouse.isBlank() || operation.isBlank()) return false
        val entries = regions().toMutableList()
        val regionIndex = entries.indexOfFirst { it.name.equals(region, ignoreCase = true) }
        if (regionIndex < 0) return false
        val oldRegion = entries[regionIndex]
        val warehouses = oldRegion.warehouses.toMutableList()
        val warehouseIndex = warehouses.indexOfFirst { it.name.equals(warehouse, ignoreCase = true) }
        if (warehouseIndex < 0) return false
        val oldWarehouse = warehouses[warehouseIndex]
        if (oldWarehouse.operations.any { it.equals(operation, ignoreCase = true) }) return false
        warehouses[warehouseIndex] = oldWarehouse.copy(operations = oldWarehouse.operations + operation)
        entries[regionIndex] = oldRegion.copy(warehouses = warehouses)
        saveRegions(entries)
        return true
    }

    private fun parseRegions(array: JSONArray): List<LocalRegionEntry> = buildList {
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            val name = normalize(item.optString("name"))
            if (name.isBlank()) continue
            val warehouses = parseWarehouses(item.optJSONArray("warehouses") ?: JSONArray())
            add(LocalRegionEntry(name, warehouses))
        }
    }

    private fun parseWarehouses(array: JSONArray): List<LocalWarehouseEntry> = buildList {
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            val name = normalize(item.optString("name"))
            if (name.isBlank()) continue
            val operationsJson = item.optJSONArray("operations") ?: JSONArray()
            val operations = buildList<String> {
                for (j in 0 until operationsJson.length()) {
                    val operation = normalize(operationsJson.optString(j))
                    if (operation.isNotBlank() && none { it.equals(operation, true) }) add(operation)
                }
            }
            if (none { it.name.equals(name, true) }) add(LocalWarehouseEntry(name, operations))
        }
    }

    private fun saveRegions(regions: List<LocalRegionEntry>) {
        val regionArray = JSONArray()
        regions.forEach { region ->
            val warehouseArray = JSONArray()
            region.warehouses.forEach { warehouse ->
                warehouseArray.put(JSONObject().apply {
                    put("name", warehouse.name)
                    put("operations", JSONArray(warehouse.operations))
                })
            }
            regionArray.put(JSONObject().apply {
                put("name", region.name)
                put("warehouses", warehouseArray)
            })
        }
        preferences.edit().putString(KEY_CATALOG, JSONObject().put("regions", regionArray).toString()).apply()
    }

    private fun readRoot(): JSONObject = runCatching {
        JSONObject(preferences.getString(KEY_CATALOG, "{}") ?: "{}")
    }.getOrDefault(JSONObject())

    private fun normalize(value: String): String = value.trim().replace(Regex("\\s+"), " ")

    private companion object {
        const val KEY_CATALOG = "catalog_json"
        const val UNSPECIFIED_REGION = "Регион не указан"
    }
}
