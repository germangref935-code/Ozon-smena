#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

command -v java >/dev/null 2>&1 || { echo 'JDK 17 не найден в PATH' >&2; exit 1; }
command -v gradle >/dev/null 2>&1 || { echo 'Gradle 8.11.1 не найден в PATH' >&2; exit 1; }
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
[[ -n "$SDK" && -d "$SDK" ]] || { echo 'Укажите ANDROID_HOME или ANDROID_SDK_ROOT' >&2; exit 1; }

gradle :app:testDebugUnitTest :app:assembleDebug --no-daemon
APK='app/build/outputs/apk/debug/app-debug.apk'
[[ -f "$APK" ]] || { echo "APK не найден: $APK" >&2; exit 1; }
mkdir -p dist
cp -f "$APK" 'dist/Ozon-Shift-Catcher-0.4.2-debug.apk'
echo 'Готово: dist/Ozon-Shift-Catcher-0.4.2-debug.apk'
