$ErrorActionPreference = 'Stop'
$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ProjectRoot

if (-not (Get-Command java -ErrorAction SilentlyContinue)) {
    throw 'JDK не найден. Установите JDK 17 и добавьте java в PATH.'
}
if (-not (Get-Command gradle -ErrorAction SilentlyContinue)) {
    throw 'Gradle не найден. Установите Gradle 8.11.1 и добавьте gradle в PATH.'
}
$Sdk = $env:ANDROID_HOME
if ([string]::IsNullOrWhiteSpace($Sdk)) { $Sdk = $env:ANDROID_SDK_ROOT }
if ([string]::IsNullOrWhiteSpace($Sdk) -or -not (Test-Path $Sdk)) {
    throw 'Android SDK не найден. Укажите ANDROID_HOME или ANDROID_SDK_ROOT.'
}

Write-Host 'Проверка и сборка Ozon Shift Catcher 0.4.2...' -ForegroundColor Cyan
& gradle :app:testDebugUnitTest :app:assembleDebug --no-daemon
if ($LASTEXITCODE -ne 0) { throw "Gradle завершился с кодом $LASTEXITCODE" }

$Apk = Join-Path $ProjectRoot 'app/build/outputs/apk/debug/app-debug.apk'
if (-not (Test-Path $Apk)) { throw "APK не найден после сборки: $Apk" }
$Dist = Join-Path $ProjectRoot 'dist'
New-Item -ItemType Directory -Force -Path $Dist | Out-Null
$Output = Join-Path $Dist 'Ozon-Shift-Catcher-0.4.2-debug.apk'
Copy-Item -Force $Apk $Output
Write-Host "Готово: $Output" -ForegroundColor Green
