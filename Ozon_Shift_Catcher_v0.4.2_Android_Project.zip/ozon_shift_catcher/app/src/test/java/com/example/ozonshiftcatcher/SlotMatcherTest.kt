package com.example.ozonshiftcatcher

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime

class SlotMatcherTest {
    private val zone = ZoneId.of("Europe/Moscow")
    private val date = LocalDate.of(2026, 11, 8)

    private fun slot(
        start: ZonedDateTime,
        end: ZonedDateTime,
        availability: BookingAvailability = BookingAvailability.IMMEDIATE,
        warehouse: String = "Хаб Север",
        operation: String = "Сортировка"
    ) = AvailableSlot("slot-1", warehouse, operation, start, end, availability)

    private fun criteria(
        window: ShiftWindow = ShiftWindow.NIGHT,
        duration: DurationFilter = DurationFilter.ANY,
        allowQueue: Boolean = false
    ) = ShiftCriteria(
        date = date,
        warehouseNames = setOf("хаб север"),
        operationNames = setOf("Сортировка"),
        window = window,
        duration = duration,
        allowQueue = allowQueue
    )

    @Test
    fun matchesNightSlotAcrossMidnight() {
        val candidate = slot(
            date.atTime(20, 0).atZone(zone),
            date.plusDays(1).atTime(4, 0).atZone(zone)
        )
        assertTrue(SlotMatcher.matches(candidate, criteria(duration = DurationFilter.H8)))
    }

    @Test
    fun rejectsSlotOutsideRequestedWindow() {
        val candidate = slot(
            date.atTime(19, 0).atZone(zone),
            date.atTime(23, 0).atZone(zone)
        )
        assertFalse(SlotMatcher.matches(candidate, criteria()))
    }

    @Test
    fun rejectsQueueWhenNotAllowed() {
        val candidate = slot(
            date.atTime(20, 0).atZone(zone),
            date.plusDays(1).atTime(8, 0).atZone(zone),
            BookingAvailability.QUEUE
        )
        assertFalse(SlotMatcher.matches(candidate, criteria(duration = DurationFilter.H12)))
        assertTrue(SlotMatcher.matches(candidate, criteria(duration = DurationFilter.H12, allowQueue = true)))
    }

    @Test
    fun filtersByWarehouseAndOperation() {
        val candidate = slot(
            date.atTime(20, 0).atZone(zone),
            date.plusDays(1).atTime(8, 0).atZone(zone),
            warehouse = "Хаб Юг"
        )
        assertFalse(SlotMatcher.matches(candidate, criteria()))
    }

    @Test
    fun matchesDaySlotAndRejectsWrongDuration() {
        val candidate = slot(
            date.atTime(8, 0).atZone(zone),
            date.atTime(14, 0).atZone(zone)
        )
        assertTrue(SlotMatcher.matches(candidate, criteria(window = ShiftWindow.DAY, duration = DurationFilter.H6)))
        assertFalse(SlotMatcher.matches(candidate, criteria(window = ShiftWindow.DAY, duration = DurationFilter.H8)))
    }
}
