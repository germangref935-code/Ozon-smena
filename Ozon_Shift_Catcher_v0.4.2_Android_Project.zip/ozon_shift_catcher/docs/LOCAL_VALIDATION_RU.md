# Локальная проверка ядра 0.4.2

Проверки выполнены в рабочей среде 8 ноября 2026 года.

- `SlotMatcher.kt` + `HotShiftTracker.kt` успешно скомпилированы Kotlin compiler 1.9.0 на JDK 21.
- Выполнены 8 smoke assertions: фильтр ночного окна, исключение дневного слота, исключение/разрешение очереди, первый снимок как baseline, распознавание нового слота, сохранение статуса существующего слота и распознавание вернувшегося слота.
- `AndroidManifest.xml` и `styles.xml` успешно разобраны XML-парсером.
- APK 0.2.0 из входных материалов имеет подпись с SHA-256 отпечатком, записанным в `BUILD_APK_RU.md`.

Это не заменяет полную сборку и запуск на Android. `MainActivity` и Android resources здесь не компилировались: Android SDK отсутствует. Полный Gradle unit-test/build workflow включён в `.github/workflows/android-build.yml` и должен выполниться в Android Studio или GitHub Actions.
