package com.example.ozonshiftcatcher

import java.time.Duration
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZonedDateTime
import java.util.Locale

/**
 * Pure matching logic for slots returned by a future, explicitly authorized Ozon Job API.
 * It does not make network requests and does not perform bookings.
 */
enum class ShiftWindow {
    DAY, NIGHT
}

enum class DurationFilter(val hours: Long?) {
    ANY(null), H4(4), H6(6), H8(8), H12(12)
}

enum class BookingAvailability {
    IMMEDIATE, QUEUE
}

data class ShiftCriteria(
    val date: LocalDate,
    val warehouseNames: Set<String>,
    val operationNames: Set<String>,
    val window: ShiftWindow,
    val duration: DurationFilter = DurationFilter.ANY,
    val allowQueue: Boolean = false
)

data class AvailableSlot(
    val slotId: String,
    val warehouseName: String,
    val operationName: String,
    val startsAt: ZonedDateTime,
    val endsAt: ZonedDateTime,
    val availability: BookingAvailability
)

object SlotMatcher {
    fun matches(slot: AvailableSlot, criteria: ShiftCriteria): Boolean {
        if (criteria.warehouseNames.isNotEmpty() &&
            normalize(slot.warehouseName) !in criteria.warehouseNames.map(::normalize).toSet()
        ) return false

        if (criteria.operationNames.isNotEmpty() &&
            normalize(slot.operationName) !in criteria.operationNames.map(::normalize).toSet()
        ) return false

        if (slot.endsAt <= slot.startsAt) return false
        if (slot.availability == BookingAvailability.QUEUE && !criteria.allowQueue) return false

        val zone = slot.startsAt.zone
        val windowStart: ZonedDateTime
        val windowEnd: ZonedDateTime
        when (criteria.window) {
            ShiftWindow.DAY -> {
                windowStart = criteria.date.atTime(LocalTime.of(8, 0)).atZone(zone)
                windowEnd = criteria.date.atTime(LocalTime.of(20, 0)).atZone(zone)
            }
            ShiftWindow.NIGHT -> {
                windowStart = criteria.date.atTime(LocalTime.of(20, 0)).atZone(zone)
                windowEnd = criteria.date.plusDays(1).atTime(LocalTime.of(8, 0)).atZone(zone)
            }
        }

        // A slot must fit completely inside the requested time window.
        if (slot.startsAt.isBefore(windowStart) || slot.endsAt.isAfter(windowEnd)) return false

        val requiredHours = criteria.duration.hours ?: return true
        val actualMinutes = Duration.between(slot.startsAt, slot.endsAt).toMinutes()
        return actualMinutes == requiredHours * 60
    }

    private fun normalize(value: String): String =
        value.trim().lowercase(Locale.ROOT).replace(Regex("\\s+"), " ")
}
