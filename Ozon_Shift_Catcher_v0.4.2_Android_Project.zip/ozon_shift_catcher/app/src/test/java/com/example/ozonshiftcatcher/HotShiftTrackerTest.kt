package com.example.ozonshiftcatcher

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime

class HotShiftTrackerTest {
    private val date = LocalDate.of(2026, 11, 8)
    private val zone = ZoneId.of("Europe/Moscow")

    private fun slot(
        id: String,
        startHour: Int,
        availability: BookingAvailability = BookingAvailability.IMMEDIATE
    ) = AvailableSlot(
        slotId = id,
        warehouseName = "Хаб Север",
        operationName = "Сортировка",
        startsAt = date.atTime(startHour, 0).atZone(zone),
        endsAt = date.atTime(startHour, 0).atZone(zone).plusHours(4),
        availability = availability
    )

    @Test
    fun firstSnapshotIsBaselineNotHot() {
        val tracker = HotShiftTracker()
        val result = tracker.observeSuccessfulSnapshot(listOf(slot("old-id", 20)))
        assertEquals(SlotFreshness.BASELINE, result.single().freshness)
        assertFalse(result.single().isHot)
    }

    @Test
    fun newlyAppearedSlotIsMarkedHotEvenIfBackendChangesSlotId() {
        val tracker = HotShiftTracker()
        tracker.observeSuccessfulSnapshot(listOf(slot("old-id", 20)))
        val result = tracker.observeSuccessfulSnapshot(listOf(slot("different-server-id", 20), slot("new-id", 21)))
        assertEquals(2, result.size)
        assertEquals(SlotFreshness.NEW, result.first { it.slot.startsAt.hour == 21 }.freshness)
        assertEquals(SlotFreshness.STILL_AVAILABLE, result.first { it.slot.startsAt.hour == 20 }.freshness)
    }

    @Test
    fun disappearedAndReturnedSlotIsMarkedReappeared() {
        val tracker = HotShiftTracker()
        tracker.observeSuccessfulSnapshot(listOf(slot("slot-a", 20)))
        tracker.observeSuccessfulSnapshot(emptyList())
        val returned = tracker.observeSuccessfulSnapshot(listOf(slot("slot-a-again", 20))).single()
        assertEquals(SlotFreshness.REAPPEARED, returned.freshness)
        assertTrue(returned.isHot)
    }

    @Test
    fun hotOnlyDropsBaselineAndStillAvailableSlots() {
        val tracker = HotShiftTracker()
        tracker.observeSuccessfulSnapshot(listOf(slot("existing", 20)))
        val next = tracker.observeSuccessfulSnapshot(listOf(slot("existing", 20), slot("new", 21)))
        assertEquals(listOf(21), tracker.hotOnly(next).map { it.slot.startsAt.hour })
    }

    @Test
    fun immediateSlotsRankBeforeQueueSlots() {
        val tracker = HotShiftTracker()
        tracker.observeSuccessfulSnapshot(emptyList())
        val ordered = tracker.observeSuccessfulSnapshot(
            listOf(
                slot("queue", 20, BookingAvailability.QUEUE),
                slot("instant", 21, BookingAvailability.IMMEDIATE)
            )
        )
        assertEquals(BookingAvailability.IMMEDIATE, ordered.first().slot.availability)
    }
}
