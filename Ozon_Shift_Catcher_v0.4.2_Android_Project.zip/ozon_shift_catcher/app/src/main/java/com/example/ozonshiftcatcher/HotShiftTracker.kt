package com.example.ozonshiftcatcher

import java.time.Instant
import java.util.Locale

/**
 * Labels slots that have just appeared or returned after disappearing.
 * Call observeSuccessfulSnapshot() only after a complete, successful response
 * from an authorised data source. Never feed an API error as an empty snapshot.
 */
enum class SlotFreshness {
    BASELINE,
    NEW,
    REAPPEARED,
    STILL_AVAILABLE
}

data class HotShiftCandidate(
    val slot: AvailableSlot,
    val freshness: SlotFreshness,
    val observedAt: Instant
) {
    val isHot: Boolean
        get() = freshness == SlotFreshness.NEW || freshness == SlotFreshness.REAPPEARED
}

class HotShiftTracker {
    private var hasBaseline = false
    private var previousSnapshot: Set<String> = emptySet()
    private val everSeen = mutableSetOf<String>()

    /**
     * First response establishes a baseline and is not treated as newly released.
     * Later slots not present in the previous snapshot are NEW or REAPPEARED.
     */
    fun observeSuccessfulSnapshot(
        slots: List<AvailableSlot>,
        observedAt: Instant = Instant.now()
    ): List<HotShiftCandidate> {
        val uniqueSlots = slots.distinctBy(::fingerprint)
        val currentKeys = uniqueSlots.map(::fingerprint).toSet()

        val candidates = uniqueSlots.map { slot ->
            val key = fingerprint(slot)
            val freshness = when {
                !hasBaseline -> SlotFreshness.BASELINE
                key !in everSeen -> SlotFreshness.NEW
                key !in previousSnapshot -> SlotFreshness.REAPPEARED
                else -> SlotFreshness.STILL_AVAILABLE
            }
            HotShiftCandidate(slot, freshness, observedAt)
        }

        everSeen += currentKeys
        previousSnapshot = currentKeys
        hasBaseline = true

        // Freshly appeared instant-confirmation slots rank first. Queue candidates
        // remain behind immediate booking candidates and must be explicitly allowed.
        return candidates.sortedWith(
            compareBy<HotShiftCandidate> { if (it.slot.availability == BookingAvailability.IMMEDIATE) 0 else 1 }
                .thenBy { freshnessRank(it.freshness) }
                .thenBy { it.slot.startsAt }
                .thenBy { normalize(it.slot.warehouseName) }
                .thenBy { normalize(it.slot.operationName) }
        )
    }

    fun hotOnly(candidates: List<HotShiftCandidate>): List<HotShiftCandidate> =
        candidates.filter { it.isHot }

    fun reset() {
        hasBaseline = false
        previousSnapshot = emptySet()
        everSeen.clear()
    }

    private fun freshnessRank(freshness: SlotFreshness): Int = when (freshness) {
        SlotFreshness.NEW -> 0
        SlotFreshness.REAPPEARED -> 1
        SlotFreshness.STILL_AVAILABLE -> 2
        SlotFreshness.BASELINE -> 3
    }

    /** Stable key independent of a server-side slot ID that may change per response. */
    private fun fingerprint(slot: AvailableSlot): String = listOf(
        normalize(slot.warehouseName),
        normalize(slot.operationName),
        slot.startsAt.toInstant().toString(),
        slot.endsAt.toInstant().toString()
    ).joinToString("|")

    private fun normalize(value: String): String =
        value.trim().lowercase(Locale.ROOT).replace(Regex("\\s+"), " ")
}
