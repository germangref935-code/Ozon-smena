package com.example.ozonshiftcatcher

import java.time.Instant
import java.time.LocalDate

/**
 * Contract boundary for a future Ozon-approved worker API integration.
 * No implementation is supplied because no public worker-facing API or
 * permission for automated slot polling/booking has been confirmed.
 */
data class WorkerCatalogSnapshot(
    val regionName: String,
    val warehouses: List<WorkerWarehouse>,
    val loadedAt: Instant
)

data class WorkerWarehouse(
    val warehouseId: String,
    val name: String,
    val operations: List<WorkerOperation>
)

data class WorkerOperation(
    val operationId: String,
    val name: String
)

data class ShiftFeedRequest(
    val warehouseIds: Set<String>,
    val operationIds: Set<String>,
    val date: LocalDate
)

data class ShiftFeedSnapshot(
    val slots: List<AvailableSlot>,
    val fetchedAt: Instant,
    val complete: Boolean
)

enum class BookingResultStatus {
    CONFIRMED,
    QUEUED,
    REJECTED,
    UNKNOWN
}

data class BookingResult(
    val slotId: String,
    val status: BookingResultStatus,
    val message: String? = null
)

interface OzonJobWorkerApi {
    /** Load only the current authenticated worker's accessible region/warehouse catalogue. */
    fun loadWorkerCatalog(): WorkerCatalogSnapshot

    /** Return a complete snapshot for the requested date and selected warehouse/process pairs. */
    fun loadAvailableSlots(request: ShiftFeedRequest): ShiftFeedSnapshot

    /** Submit an authorised booking request; implementation must use supported idempotency rules. */
    fun bookSlot(slotId: String, idempotencyKey: String): BookingResult
}
