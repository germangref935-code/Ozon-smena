package com.example.ozonshiftcatcher

import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * Ozon Shift Catcher — local task configurator.
 *
 * This app intentionally does not log in to Ozon, collect credentials/OTP/cookies,
 * inspect private app traffic, or call undocumented endpoints. Live monitoring and
 * booking remain disabled until Ozon provides written permission and a documented
 * worker-facing API with published rate limits.
 */
class MainActivity : Activity() {
    private lateinit var regionSpinner: Spinner
    private lateinit var warehouseSpinner: Spinner
    private lateinit var operationSpinner: Spinner
    private lateinit var hotOnlyCheckBox: CheckBox
    private lateinit var shiftGroup: RadioGroup
    private lateinit var durationGroup: RadioGroup
    private lateinit var bookingModeGroup: RadioGroup
    private lateinit var dateButton: Button
    private lateinit var taskStatus: TextView

    private var selectedDate: Calendar = Calendar.getInstance()
    private val prefs by lazy { getSharedPreferences("shift_settings_v3", MODE_PRIVATE) }
    private val catalog by lazy { LocalCatalogStore(this) }

    companion object {
        private const val KEY_WAREHOUSES = "warehouses"
        private const val KEY_OPERATIONS = "operations"
        private const val KEY_SHIFT = "shift_window"
        private const val KEY_DURATION = "duration_filter"
        private const val KEY_QUEUE_ALLOWED = "queue_allowed"
        private const val KEY_DATE = "date"
        private const val KEY_TASK_SAVED = "task_saved"
        private const val KEY_SELECTED_REGION = "selected_region"
        private const val KEY_SELECTED_WAREHOUSE = "selected_warehouse"
        private const val KEY_SELECTED_OPERATION = "selected_operation"
        private const val KEY_HOT_ONLY = "hot_only"

        private val COLOR_BACKGROUND = 0xFF0E151C.toInt()
        private val COLOR_CARD = 0xFF18232D.toInt()
        private val COLOR_INPUT = 0xFF202B35.toInt()
        private val COLOR_BUTTON = 0xFF263746.toInt()
        private val COLOR_ACCENT = 0xFF40E0D0.toInt()
        private val COLOR_TEXT = 0xFFFFFFFF.toInt()
        private val COLOR_DARK_TEXT = 0xFF102027.toInt()
        private val COLOR_MUTED = 0xFF9EADB8.toInt()
        private val COLOR_HINT = 0xFF82919B.toInt()
        private val COLOR_LABEL = 0xFFB6C1C9.toInt()
        private val COLOR_WARNING = 0xFFFFC857.toInt()

        private const val OZON_JOB_PACKAGE = "ru.ozon.hire"
        private const val OZON_JOB_OFFICIAL_PAGE = "https://job.ozon.ru/app"
        private const val OZON_JOB_HELP_PAGE = "https://docs.ozon.ru/job-ff-help/shifts/take-shifts/"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        migrateLegacySettings()
        migrateProfileToLocalCatalog()
        restoreSettings()
        buildScreen()
        refreshCatalogSpinners()
        refreshTaskStatus()
    }

    private fun migrateLegacySettings() {
        val legacy = getSharedPreferences("shift_settings", MODE_PRIVATE)
        if (prefs.getBoolean(KEY_TASK_SAVED, false) || !legacy.getBoolean("task_saved", false)) return

        prefs.edit()
            .putString(KEY_WAREHOUSES, legacy.getString("warehouse", "").orEmpty())
            .putString(KEY_OPERATIONS, legacy.getString("operation", "").orEmpty())
            .putString(KEY_SHIFT, legacy.getString("shift", ShiftWindow.NIGHT.name) ?: ShiftWindow.NIGHT.name)
            .putString(KEY_DURATION, DurationFilter.ANY.name)
            .putBoolean(KEY_QUEUE_ALLOWED, false)
            .putString(KEY_DATE, legacy.getString("date", ""))
            .putBoolean(KEY_TASK_SAVED, true)
            .apply()
    }

    private fun restoreSettings() {
        prefs.getString(KEY_DATE, null)?.takeIf { it.isNotBlank() }?.let { stored ->
            runCatching {
                val parsed = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(stored)
                if (parsed != null) selectedDate.time = parsed
            }
        }
        val today = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (selectedDate.before(today)) selectedDate = today
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(28))
            setBackgroundColor(COLOR_BACKGROUND)
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(root)
        }

        root.addView(label("OZON SHIFT CATCHER", COLOR_ACCENT, 11f, true), matchWrap())
        root.addView(label("Ловец горящих смен", COLOR_TEXT, 27f, true).apply {
            setPadding(0, dp(7), 0, dp(5))
        }, matchWrap())
        root.addView(label(
            "Приоритет — новым слотам, которые только что появились и могут быстро исчезнуть.",
            COLOR_MUTED, 14f
        ), matchWrap())

        root.addView(sectionLabel("1. ПОДКЛЮЧЕНИЕ"), matchWrap(dp(22)))
        val connectionCard = card()
        connectionCard.addView(label("НЕТ СИНХРОНИЗАЦИИ С АККАУНТОМ", COLOR_WARNING, 12f, true), matchWrap())
        connectionCard.addView(label(
            "Кнопка ниже только открывает официальное приложение. Мы не можем определить, выполнен ли там вход, и не получаем из его сессии список доступных складов, операций или времени слотов. Пароль, SMS-код и cookies приложение не запрашивает.",
            COLOR_TEXT, 13f
        ).apply { setPadding(0, dp(8), 0, dp(12)) }, matchWrap())
        connectionCard.addView(actionButton(
            "ОТКРЫТЬ ОФИЦИАЛЬНЫЙ OZON JOB", COLOR_BUTTON, COLOR_TEXT
        ).apply { setOnClickListener { openOzonJob() } }, matchWrap())
        connectionCard.addView(actionButton(
            "КАК ЗАПИСЫВАЮТСЯ НА СЛОТЫ", COLOR_BUTTON, COLOR_TEXT
        ).apply { setOnClickListener { openUrl(OZON_JOB_HELP_PAGE) } }, matchWrap(dp(8)))
        connectionCard.addView(label(
            "Автопоиск и автобронирование выключены. В опубликованных условиях Ozon есть запрет на ботов/парсеры и чрезмерную нагрузку. Для серверной интеграции необходимо письменное разрешение и документированный API для исполнителей.",
            COLOR_MUTED, 12f
        ).apply { setPadding(0, dp(10), 0, 0) }, matchWrap())
        root.addView(connectionCard, matchWrap())

        root.addView(sectionLabel("2. РЕГИОН · СКЛАД · ОПЕРАЦИЯ"), matchWrap(dp(22)))
        val catalogCard = card()
        catalogCard.addView(label("ЛОКАЛЬНЫЙ СПРАВОЧНИК", COLOR_ACCENT, 12f, true), matchWrap())
        catalogCard.addView(label(
            "Каталог организован по регионам: у каждого региона свой список складов, а у каждого склада — свои операции. Пока это локальный справочник: данные добавляются вручную и не выдаются за фактический список из аккаунта Ozon Job.",
            COLOR_TEXT, 12f
        ).apply { setPadding(0, dp(7), 0, dp(12)) }, matchWrap())

        catalogCard.addView(fieldLabel("РЕГИОН"), matchWrap())
        regionSpinner = catalogSpinner()
        catalogCard.addView(regionSpinner, matchWrap(dp(6)))
        catalogCard.addView(actionButton("+ ДОБАВИТЬ РЕГИОН", COLOR_BUTTON, COLOR_TEXT).apply {
            setOnClickListener { showCatalogEntryDialog("Название региона") { name ->
                if (catalog.addRegion(name)) {
                    prefs.edit().putString(KEY_SELECTED_REGION, name.trim()).apply()
                    prefs.edit().remove(KEY_SELECTED_WAREHOUSE).remove(KEY_SELECTED_OPERATION).apply()
                    refreshCatalogSpinners(name.trim(), null, null)
                    toast("Регион добавлен")
                } else toast("Такой регион уже есть или название пустое")
            } }
        }, matchWrap(dp(6)))

        catalogCard.addView(fieldLabel("СКЛАД В ВЫБРАННОМ РЕГИОНЕ"), matchWrap(dp(14)))
        warehouseSpinner = catalogSpinner()
        catalogCard.addView(warehouseSpinner, matchWrap(dp(6)))
        catalogCard.addView(actionButton("+ ДОБАВИТЬ СКЛАД", COLOR_BUTTON, COLOR_TEXT).apply {
            setOnClickListener {
                val region = selectedRegionName()
                if (region == null) {
                    toast("Сначала добавь или выбери регион")
                } else showCatalogEntryDialog("Название склада") { name ->
                    if (catalog.addWarehouse(region, name)) {
                        prefs.edit().putString(KEY_SELECTED_WAREHOUSE, name.trim()).apply()
                        refreshCatalogSpinners(region, name.trim(), null)
                        toast("Склад добавлен в регион")
                    } else toast("Такой склад уже есть в этом регионе или название пустое")
                }
            }
        }, matchWrap(dp(6)))

        catalogCard.addView(fieldLabel("ОПЕРАЦИЯ НА ВЫБРАННОМ СКЛАДЕ"), matchWrap(dp(14)))
        operationSpinner = catalogSpinner()
        catalogCard.addView(operationSpinner, matchWrap(dp(6)))
        catalogCard.addView(actionButton("+ ДОБАВИТЬ ОПЕРАЦИЮ", COLOR_BUTTON, COLOR_TEXT).apply {
            setOnClickListener {
                val region = selectedRegionName()
                val warehouse = selectedWarehouseName()
                if (region == null || warehouse == null) {
                    toast("Сначала выбери регион и склад")
                } else showCatalogEntryDialog("Название операции") { operation ->
                    if (catalog.addOperation(region, warehouse, operation)) {
                        prefs.edit().putString(KEY_SELECTED_OPERATION, operation.trim()).apply()
                        refreshCatalogSpinners(region, warehouse, operation.trim())
                        toast("Операция добавлена для склада")
                    } else toast("Операция уже есть или название пустое")
                }
            }
        }, matchWrap(dp(6)))
        catalogCard.addView(helpText(
            "При смене региона обновляется список складов, при смене склада — список операций. Для реального аккаунта каталог должен поступать из разрешённого источника Ozon Job."
        ).apply { setPadding(0, dp(9), 0, 0) }, matchWrap())
        root.addView(catalogCard, matchWrap())

        root.addView(sectionLabel("3. ПАРАМЕТРЫ СМЕНЫ"), matchWrap(dp(22)))
        root.addView(fieldLabel("ДАТА НАЧАЛА СМЕНЫ"), matchWrap())
        dateButton = actionButton("", COLOR_INPUT, COLOR_TEXT).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), 0, dp(14), 0)
            setOnClickListener { showDatePicker() }
        }
        updateDateButton()
        root.addView(dateButton, matchWrap(dp(6)))

        root.addView(fieldLabel("ВРЕМЕННОЕ ОКНО"), matchWrap(dp(16)))
        shiftGroup = radioGroup()
        val savedShift = prefs.getString(KEY_SHIFT, ShiftWindow.NIGHT.name)
        shiftGroup.addView(shiftRadio("Ночь · 20:00–08:00 следующего дня", ShiftWindow.NIGHT.name,
            savedShift == ShiftWindow.NIGHT.name), matchWrap())
        shiftGroup.addView(shiftRadio("День · 08:00–20:00", ShiftWindow.DAY.name,
            savedShift == ShiftWindow.DAY.name), matchWrap())
        root.addView(shiftGroup, matchWrap(dp(6)))
        root.addView(helpText(
            "Дата относится к началу окна. Ночная смена заканчивается утром следующего календарного дня."
        ), matchWrap(dp(4)))

        root.addView(fieldLabel("ПРОДОЛЖИТЕЛЬНОСТЬ СЛОТА"), matchWrap(dp(16)))
        durationGroup = radioGroup()
        val savedDuration = prefs.getString(KEY_DURATION, DurationFilter.ANY.name)
        listOf(
            DurationFilter.ANY to "Любая доступная",
            DurationFilter.H4 to "4 часа",
            DurationFilter.H6 to "6 часов",
            DurationFilter.H8 to "8 часов",
            DurationFilter.H12 to "12 часов"
        ).forEach { (filter, title) ->
            durationGroup.addView(shiftRadio(title, filter.name, savedDuration == filter.name), matchWrap())
        }
        root.addView(durationGroup, matchWrap(dp(6)))
        root.addView(helpText(
            "В Ozon Job встречаются слоты на 4, 6, 8 и 12 часов. Какие варианты доступны, определяет конкретный склад."
        ), matchWrap(dp(4)))

        root.addView(fieldLabel("ТИП ЗАПИСИ"), matchWrap(dp(16)))
        bookingModeGroup = radioGroup()
        val queueAllowed = prefs.getBoolean(KEY_QUEUE_ALLOWED, false)
        bookingModeGroup.addView(shiftRadio(
            "Только мгновенное подтверждение", "INSTANT_ONLY", !queueAllowed
        ), matchWrap())
        bookingModeGroup.addView(shiftRadio(
            "Разрешить также очередь", "QUEUE_ALLOWED", queueAllowed
        ), matchWrap())
        root.addView(bookingModeGroup, matchWrap(dp(6)))
        root.addView(helpText(
            "Очередь не равна подтверждённой записи: Ozon обрабатывает её отдельно и сообщает результат позже."
        ), matchWrap(dp(4)))

        root.addView(sectionLabel("4. ПРИОРИТЕТ ГОРЯЩИХ СМЕН"), matchWrap(dp(22)))
        hotOnlyCheckBox = CheckBox(this).apply {
            text = "Ловить только новые и вернувшиеся слоты"
            textSize = 14f
            setTextColor(COLOR_TEXT)
            buttonTintList = ColorStateList.valueOf(COLOR_ACCENT)
            isChecked = prefs.getBoolean(KEY_HOT_ONLY, true)
            setPadding(dp(4), dp(6), dp(4), dp(6))
        }
        root.addView(hotOnlyCheckBox, matchWrap())
        root.addView(helpText(
            "Первый успешный снимок доступности станет базовым. Затем новые слоты и слоты, которые исчезали и снова появились, получат высший приоритет. Сначала ранжируются варианты с мгновенным подтверждением, затем очередь. Этот механизм заработает только после подключения разрешённого источника данных."
        ), matchWrap(dp(2)))

        root.addView(sectionLabel("5. СОХРАНЕНИЕ ЗАДАНИЯ"), matchWrap(dp(22)))
        taskStatus = label("Задание ещё не сохранено", COLOR_WARNING, 13f, true).apply {
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(COLOR_INPUT)
        }
        root.addView(taskStatus, matchWrap())
        root.addView(actionButton(
            "СОХРАНИТЬ ПАРАМЕТРЫ", COLOR_ACCENT, COLOR_DARK_TEXT
        ).apply { setOnClickListener { saveTask() } }, matchWrap(dp(12)))

        root.addView(label(
            "Сейчас это локальная настройка и логика отбора новых слотов. Живой каталог, серверный опрос и бронирование не подключены: для них нужен документированный API и разрешение Ozon.",
            COLOR_MUTED, 11f
        ).apply { setPadding(0, dp(18), 0, 0) }, matchWrap())

        setContentView(scroll)
    }

    private fun migrateProfileToLocalCatalog() {
        val oldWarehouses = parseLines(prefs.getString(KEY_WAREHOUSES, "").orEmpty())
        val oldOperations = parseLines(prefs.getString(KEY_OPERATIONS, "").orEmpty())
        if (catalog.regions().isEmpty() && oldWarehouses.isNotEmpty()) {
            val legacyRegion = "Регион не указан"
            catalog.addRegion(legacyRegion)
            oldWarehouses.forEach { warehouse ->
                catalog.addWarehouse(legacyRegion, warehouse)
                oldOperations.forEach { operation -> catalog.addOperation(legacyRegion, warehouse, operation) }
            }
        }

        val firstRegion = catalog.regions().firstOrNull()?.name
        val storedRegion = prefs.getString(KEY_SELECTED_REGION, null)
        if (storedRegion.isNullOrBlank() || catalog.regions().none { it.name.equals(storedRegion, true) }) {
            prefs.edit().putString(KEY_SELECTED_REGION, firstRegion).apply()
        }
        val region = prefs.getString(KEY_SELECTED_REGION, null)
        val regionWarehouses = region?.let(catalog::warehouses).orEmpty().map { it.name }
        val storedWarehouse = prefs.getString(KEY_SELECTED_WAREHOUSE, null)
        if (storedWarehouse.isNullOrBlank() || regionWarehouses.none { it.equals(storedWarehouse, true) }) {
            prefs.edit().putString(KEY_SELECTED_WAREHOUSE, regionWarehouses.firstOrNull()).apply()
        }
        if (prefs.getString(KEY_SELECTED_OPERATION, null) == null) {
            val warehouse = prefs.getString(KEY_SELECTED_WAREHOUSE, null)
            val firstOperation = if (region != null && warehouse != null) {
                catalog.operations(region, warehouse).firstOrNull()
            } else null
            prefs.edit().putString(KEY_SELECTED_OPERATION, firstOperation).apply()
        }
        if (!prefs.contains(KEY_HOT_ONLY)) prefs.edit().putBoolean(KEY_HOT_ONLY, true).apply()
    }

    private fun catalogSpinner() = Spinner(this).apply {
        setBackgroundColor(COLOR_INPUT)
        setPadding(dp(8), dp(4), dp(8), dp(4))
    }

    private fun refreshCatalogSpinners(
        preferredRegion: String? = prefs.getString(KEY_SELECTED_REGION, null),
        preferredWarehouse: String? = prefs.getString(KEY_SELECTED_WAREHOUSE, null),
        preferredOperation: String? = prefs.getString(KEY_SELECTED_OPERATION, null)
    ) {
        if (!::regionSpinner.isInitialized || !::warehouseSpinner.isInitialized || !::operationSpinner.isInitialized) return
        val regionNames = catalog.regions().map { it.name }
        val regionItems = regionNames.ifEmpty { listOf("Нет регионов — добавь вручную") }
        regionSpinner.adapter = spinnerAdapter(regionItems)
        val regionIndex = regionNames.indexOfFirst { it.equals(preferredRegion, true) }.takeIf { it >= 0 } ?: 0
        regionSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val selected = regionNames.getOrNull(position)
                if (selected != null) {
                    prefs.edit().putString(KEY_SELECTED_REGION, selected).apply()
                    refreshWarehouseSpinner(selected, null, null)
                } else refreshWarehouseSpinner(null, null, null)
            }
        }
        regionSpinner.setSelection(regionIndex, false)
        val chosenRegion = regionNames.getOrNull(regionIndex)
        if (chosenRegion != null) refreshWarehouseSpinner(chosenRegion, preferredWarehouse, preferredOperation)
        else refreshWarehouseSpinner(null, null, null)
    }

    private fun refreshWarehouseSpinner(
        region: String?,
        preferredWarehouse: String?,
        preferredOperation: String?
    ) {
        val warehouseNames = region?.let(catalog::warehouses).orEmpty().map { it.name }
        val warehouseItems = warehouseNames.ifEmpty { listOf("Нет складов — добавь вручную") }
        warehouseSpinner.adapter = spinnerAdapter(warehouseItems)
        val warehouseIndex = warehouseNames.indexOfFirst { it.equals(preferredWarehouse, true) }.takeIf { it >= 0 } ?: 0
        warehouseSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val selected = warehouseNames.getOrNull(position)
                if (selected != null) {
                    prefs.edit().putString(KEY_SELECTED_WAREHOUSE, selected).apply()
                    refreshOperationSpinner(region, selected, preferredOperation)
                } else refreshOperationSpinner(region, null, null)
            }
        }
        warehouseSpinner.setSelection(warehouseIndex, false)
        val chosenWarehouse = warehouseNames.getOrNull(warehouseIndex)
        if (chosenWarehouse != null) refreshOperationSpinner(region, chosenWarehouse, preferredOperation)
        else refreshOperationSpinner(region, null, null)
    }

    private fun refreshOperationSpinner(region: String?, warehouse: String?, preferredOperation: String?) {
        if (!::operationSpinner.isInitialized) return
        val operationNames = if (region != null && warehouse != null) {
            catalog.operations(region, warehouse)
        } else emptyList()
        val operationItems = operationNames.ifEmpty { listOf("Нет операций — добавь вручную") }
        operationSpinner.adapter = spinnerAdapter(operationItems)
        val index = operationNames.indexOfFirst { it.equals(preferredOperation, true) }.takeIf { it >= 0 } ?: 0
        operationSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                operationNames.getOrNull(position)?.let {
                    prefs.edit().putString(KEY_SELECTED_OPERATION, it).apply()
                }
            }
        }
        operationSpinner.setSelection(index, false)
        operationNames.getOrNull(index)?.let {
            prefs.edit().putString(KEY_SELECTED_OPERATION, it).apply()
        }
    }

    private fun spinnerAdapter(items: List<String>): ArrayAdapter<String> =
        ArrayAdapter(this, android.R.layout.simple_spinner_item, items).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }

    private fun selectedRegionName(): String? =
        catalog.regions().map { it.name }.getOrNull(regionSpinner.selectedItemPosition)

    private fun selectedWarehouseName(): String? {
        val region = selectedRegionName() ?: return null
        return catalog.warehouses(region).map { it.name }.getOrNull(warehouseSpinner.selectedItemPosition)
    }

    private fun selectedOperationName(): String? {
        val region = selectedRegionName() ?: return null
        val warehouse = selectedWarehouseName() ?: return null
        return catalog.operations(region, warehouse).getOrNull(operationSpinner.selectedItemPosition)
    }

    private fun showCatalogEntryDialog(title: String, onSave: (String) -> Unit) {
        val input = EditText(this).apply {
            hint = title
            setSingleLine(true)
            setTextColor(COLOR_TEXT)
            setHintTextColor(COLOR_HINT)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(COLOR_INPUT)
        }
        val container = LinearLayout(this).apply {
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(input, matchWrap())
        }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(container)
            .setNegativeButton("Отмена", null)
            .setPositiveButton("Добавить") { _, _ -> onSave(input.text.toString()) }
            .show()
    }

    private fun showDatePicker() {
        val now = Calendar.getInstance()
        DatePickerDialog(
            this,
            { _, year, month, day ->
                selectedDate.set(Calendar.YEAR, year)
                selectedDate.set(Calendar.MONTH, month)
                selectedDate.set(Calendar.DAY_OF_MONTH, day)
                updateDateButton()
            },
            selectedDate.get(Calendar.YEAR),
            selectedDate.get(Calendar.MONTH),
            selectedDate.get(Calendar.DAY_OF_MONTH)
        ).apply {
            datePicker.minDate = now.timeInMillis
        }.show()
    }

    private fun updateDateButton() {
        if (!::dateButton.isInitialized) return
        val date = SimpleDateFormat("EEEE, d MMMM yyyy", Locale("ru")).format(selectedDate.time)
        dateButton.text = "▦   ${date.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale("ru")) else it.toString() }}"
    }

    private fun saveTask() {
        val region = selectedRegionName()
        val warehouse = selectedWarehouseName()
        val operation = selectedOperationName()
        if (region == null) {
            toast("Добавь и выбери регион")
            return
        }
        if (warehouse == null) {
            toast("Добавь и выбери склад")
            return
        }
        if (operation == null) {
            toast("Добавь и выбери операцию для этого склада")
            return
        }
        val shift = selectedTag(shiftGroup) ?: run {
            toast("Выбери дневное или ночное окно")
            return
        }
        val duration = selectedTag(durationGroup) ?: run {
            toast("Выбери продолжительность")
            return
        }
        val bookingMode = selectedTag(bookingModeGroup) ?: "INSTANT_ONLY"
        val dateIso = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(selectedDate.time)

        prefs.edit()
            .putString(KEY_SELECTED_REGION, region)
            .putString(KEY_WAREHOUSES, warehouse)
            .putString(KEY_OPERATIONS, operation)
            .putString(KEY_SELECTED_WAREHOUSE, warehouse)
            .putString(KEY_SELECTED_OPERATION, operation)
            .putBoolean(KEY_HOT_ONLY, hotOnlyCheckBox.isChecked)
            .putString(KEY_SHIFT, shift)
            .putString(KEY_DURATION, duration)
            .putBoolean(KEY_QUEUE_ALLOWED, bookingMode == "QUEUE_ALLOWED")
            .putString(KEY_DATE, dateIso)
            .putBoolean(KEY_TASK_SAVED, true)
            .apply()

        refreshTaskStatus()
        toast("Параметры задания сохранены")
    }

    private fun refreshTaskStatus() {
        if (!::taskStatus.isInitialized) return
        if (!prefs.getBoolean(KEY_TASK_SAVED, false)) {
            taskStatus.text = "Задание ещё не сохранено"
            return
        }
        val warehouse = prefs.getString(KEY_SELECTED_WAREHOUSE, "")
            ?.takeIf { it.isNotBlank() }
            ?: parseLines(prefs.getString(KEY_WAREHOUSES, "").orEmpty()).firstOrNull().orEmpty()
        val operation = prefs.getString(KEY_SELECTED_OPERATION, "")
            ?.takeIf { it.isNotBlank() }
            ?: parseLines(prefs.getString(KEY_OPERATIONS, "").orEmpty()).firstOrNull().orEmpty()
        val shift = if (prefs.getString(KEY_SHIFT, ShiftWindow.NIGHT.name) == ShiftWindow.DAY.name) {
            "08:00–20:00"
        } else "20:00–08:00 (+1 день)"
        val duration = when (prefs.getString(KEY_DURATION, DurationFilter.ANY.name)) {
            DurationFilter.H4.name -> "4 ч"
            DurationFilter.H6.name -> "6 ч"
            DurationFilter.H8.name -> "8 ч"
            DurationFilter.H12.name -> "12 ч"
            else -> "любая"
        }
        val queue = if (prefs.getBoolean(KEY_QUEUE_ALLOWED, false)) "очередь допустима" else "только мгновенная запись"
        taskStatus.text = buildString {
            append("ПРОФИЛЬ СОХРАНЁН · МОНИТОРИНГ ВЫКЛЮЧЕН\n")
            append("Регион: ${prefs.getString(KEY_SELECTED_REGION, "—")}\n")
            append("Склад: $warehouse\n")
            append("Операция: $operation\n")
            append("Дата начала: ${prefs.getString(KEY_DATE, "—")}\n")
            append("Окно: $shift · длительность: $duration\n")
            append("Тип записи: $queue\n")
            append("Приоритет: ${if (prefs.getBoolean(KEY_HOT_ONLY, true)) "только новые/вернувшиеся слоты" else "все подходящие слоты"}")
        }
    }

    private fun openOzonJob() {
        val launch = packageManager.getLaunchIntentForPackage(OZON_JOB_PACKAGE)
        if (launch != null) {
            startActivity(launch)
        } else {
            openUrl(OZON_JOB_OFFICIAL_PAGE)
        }
    }

    private fun openUrl(url: String) {
        runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
            .onFailure { toast("Не удалось открыть ссылку") }
    }

    private fun parseLines(raw: String): List<String> = raw
        .split('\n', ',', ';')
        .map { it.trim() }
        .filter { it.isNotEmpty() }
        .distinctBy { it.lowercase(Locale.ROOT) }

    private fun selectedTag(group: RadioGroup): String? =
        group.findViewById<RadioButton>(group.checkedRadioButtonId)?.tag?.toString()

    private fun radioGroup() = RadioGroup(this).apply {
        orientation = RadioGroup.VERTICAL
        setPadding(dp(12), dp(5), dp(12), dp(5))
        setBackgroundColor(COLOR_INPUT)
    }

    private fun shiftRadio(title: String, value: String, checked: Boolean) = RadioButton(this).apply {
        id = View.generateViewId()
        text = title
        tag = value
        textSize = 14f
        setTextColor(COLOR_TEXT)
        buttonTintList = ColorStateList.valueOf(COLOR_ACCENT)
        isChecked = checked
        setPadding(dp(4), dp(8), dp(4), dp(8))
    }

    private fun multiLineField(hintValue: String, savedValue: String) = EditText(this).apply {
        hint = hintValue
        setSingleLine(false)
        minLines = 2
        maxLines = 5
        gravity = Gravity.TOP or Gravity.START
        textSize = 14f
        setTextColor(COLOR_TEXT)
        setHintTextColor(COLOR_HINT)
        setPadding(dp(14), dp(12), dp(14), dp(12))
        setBackgroundColor(COLOR_INPUT)
        setText(savedValue)
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(14), dp(14), dp(14))
        setBackgroundColor(COLOR_CARD)
    }

    private fun label(value: String, color: Int, size: Float, bold: Boolean = false) = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun sectionLabel(value: String) = label(value, COLOR_ACCENT, 11f, true).apply {
        letterSpacing = 0.1f
        setPadding(0, dp(2), 0, dp(9))
    }

    private fun fieldLabel(value: String) = label(value, COLOR_LABEL, 11f, true).apply {
        letterSpacing = 0.08f
    }

    private fun helpText(value: String) = label(value, COLOR_MUTED, 11f).apply {
        setPadding(dp(2), dp(3), dp(2), 0)
    }

    private fun actionButton(title: String, background: Int, foreground: Int) = Button(this).apply {
        text = title
        textSize = 12f
        isAllCaps = false
        setTextColor(foreground)
        setBackgroundColor(background)
        minHeight = dp(48)
        gravity = Gravity.CENTER
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    private fun matchWrap(top: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            if (top > 0) topMargin = top
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

}
